function crossfilter_zero() {
  return 0;
}
